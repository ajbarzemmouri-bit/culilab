(function(){
  var selected=[], tech=[], xp=0, found=[];
  var labels={boter:'🧈 Boter',bloem:'🌾 Bloem',melk:'🥛 Melk',bouillon:'🥣 Bouillon',roux:'🥘 Roux'};
  var cards=document.getElementById('cards'), pan=document.getElementById('panContents'), status=document.getElementById('status');
  function render(){pan.textContent=selected.length?selected.map(function(x){return labels[x]}).join(' + '):'Tik op ingrediënten';document.querySelectorAll('.card').forEach(function(b){b.classList.toggle('selected',selected.indexOf(b.dataset.item)>-1)});document.querySelectorAll('[data-tech]').forEach(function(b){b.classList.toggle('active',tech.indexOf(b.dataset.tech)>-1)});document.getElementById('heatGlow').classList.toggle('on',tech.indexOf('verwarmen')>-1)}
  function toast(t){var el=document.getElementById('toast');el.textContent=t;el.classList.add('show');setTimeout(function(){el.classList.remove('show')},1800)}
  function discover(name,points){if(found.indexOf(name)<0){found.push(name);xp+=points;document.getElementById('xp').textContent=xp;toast('🎉 '+name+' ontdekt! +'+points+' XP');updateBook()}}
  function updateBook(){document.getElementById('bookText').textContent=found.length?'Ontdekt: '+found.join(' • '):'Nog geen bereidingen ontdekt. Experimenteer in de pan.';var d=document.getElementById('discoveries').children;for(var i=0;i<d.length;i++){var n=d[i].textContent.replace('🔒 ','');if(found.indexOf(n)>-1)d[i].textContent='✅ '+n}}
  function addRouxCard(){if(!document.querySelector('[data-item="roux"]')){var b=document.createElement('button');b.className='card';b.dataset.item='roux';b.innerHTML='<span>🥘</span>Roux';cards.appendChild(b)}}
  cards.addEventListener('click',function(e){var b=e.target.closest('.card');if(!b)return;var item=b.dataset.item;var i=selected.indexOf(item);if(i>-1)selected.splice(i,1);else if(selected.length<2)selected.push(item);else{status.textContent='Er zitten al twee elementen in de pan. Leeg de pan of haal er één uit.';return}status.textContent='Gekozen: '+selected.map(function(x){return labels[x]}).join(' + ');render()});
  document.querySelector('.controls').addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;if(b.dataset.tech){var t=b.dataset.tech,i=tech.indexOf(t);if(i>-1)tech.splice(i,1);else tech.push(t);render()}});
  document.getElementById('clear').addEventListener('click',function(){selected=[];tech=[];status.textContent='Pan is leeg.';render()});
  document.getElementById('cook').addEventListener('click',function(){var key=selected.slice().sort().join('+');
    if(key==='bloem+boter' && tech.indexOf('verwarmen')>-1 && tech.indexOf('mengen')>-1){discover('Roux',25);addRouxCard();status.textContent='Goed! Boter en bloem vormen met warmte en mengen een roux.';selected=[];tech=[];render();return}
    if(key==='melk+roux' && tech.indexOf('verwarmen')>-1 && tech.indexOf('mengen')>-1){discover('Béchamel',100);status.textContent='Béchamel gelukt: roux + melk, verwarmd en glad gemengd.';selected=[];tech=[];render();return}
    if(key==='bouillon+roux' && tech.indexOf('verwarmen')>-1 && tech.indexOf('mengen')>-1){discover('Velouté',100);status.textContent='Velouté gelukt: roux + bouillon, verwarmd en glad gemengd.';selected=[];tech=[];render();return}
    if(selected.length<2){status.textContent='Voeg eerst twee elementen toe.';return}
    if(tech.indexOf('verwarmen')<0){status.textContent='⚠️ Er gebeurt weinig. Misschien ontbreekt warmte.';return}
    if(tech.indexOf('mengen')<0){status.textContent='💥 Klontjes! Je hebt verwarmd zonder goed te mengen.';return}
    status.textContent='🧪 Deze combinatie levert nog geen basissaus op. Probeer iets anders.';
  });render();
})();
